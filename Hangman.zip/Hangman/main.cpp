#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Hangman {
private:
    vector<string> words;
    string wordToGuess;
    string guessedWord;
    int incorrectAttempts;
    const int maxAttempts = 6;

    void loadWordsFromFile(const string& filename) {
        ifstream file(filename);

        if (!file.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            exit(EXIT_FAILURE);
        }

        string word;
        while (file >> word) {
            words.push_back(word);
        }

        file.close();
    }

    string getRandomWord() {
        srand(static_cast<unsigned int>(time(0)));
        int randomIndex = rand() % words.size();
        return words[randomIndex];
    }

    string hideWord(const string& word) {
        string hiddenWord(word.length(), '_');
        return hiddenWord;
    }

    void displayHangman() const {
        switch (incorrectAttempts) {
            case 1:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |" << endl;
                cout << "   |" << endl;
                break;
            case 2:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |      |" << endl;
                cout << "   |" << endl;
                break;
            case 3:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |     /|" << endl;
                cout << "   |" << endl;
                break;
            case 4:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |     /|\\" << endl;
                cout << "   |" << endl;
                break;
            case 5:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |     /|\\" << endl;
                cout << "   |     /" << endl;
                break;
            case 6:
                cout << "   ________" << endl;
                cout << "   |      |" << endl;
                cout << "   |      O" << endl;
                cout << "   |     /|\\" << endl;
                cout << "   |     / \\" << endl;
                break;
            default:
                break;
        }
    }

    void updateGuessedWord(char guess) {
        for (size_t i = 0; i < wordToGuess.length(); ++i) {
            if (wordToGuess[i] == guess) {
                guessedWord[i] = guess;
            }
        }
    }

public:
    Hangman(const string& filename) : incorrectAttempts(0) {
        loadWordsFromFile(filename);
        wordToGuess = getRandomWord();
        guessedWord = hideWord(wordToGuess);
    }

    void play() {
        do {
            cout << "Current word: " << guessedWord << endl;
            displayHangman();

            char guess;
            cout << "Enter your guess: ";
            cin >> guess;

            if (wordToGuess.find(guess) != string::npos) {
                updateGuessedWord(guess);
            } else {
                ++incorrectAttempts;
            }

        } while (!isGameWon() && incorrectAttempts < maxAttempts);

        if (isGameWon()) {
            cout << "Congratulations! You guessed the word: " << wordToGuess << endl;
        } else {
            cout << "Sorry, you ran out of attempts. The word was: " << wordToGuess << endl;
        }
    }

    bool isGameWon() const {
        return wordToGuess == guessedWord;
    }
};

int main() {
    const string filename = "Words.txt";
    char playAgain;

    do {
        Hangman hangmanGame(filename);
        hangmanGame.play();

        cout << "Do you want to play again? (1 for Yes, 2 for No): ";
        cin >> playAgain;

        if (playAgain != '1' && playAgain != '2') {
            cout << "Invalid input. Please enter 1 to play again or 2 to exit." << endl;
        }

    } while (playAgain == '1');
    return 0;
}

